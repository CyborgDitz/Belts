﻿// See https://aka.ms/new-console-template for more information

string name = "Arin";
int hp = 100;
float atkP = 15.5f;
bool isParalysed = true;
double gold = 24.75;

Console.WriteLine($"Character Name: {name}");
Console.WriteLine($"Health Points: {hp}");
Console.WriteLine($"Attack Power: {atkP}");
Console.WriteLine($"Is Paralysed: {isParalysed}");
Console.WriteLine($"Gold Coins: {gold}");