namespace Kata_Yellow_Exam;

public interface IAmAlive
{
    public bool AmAlive();
}