namespace Kata_Yellow_Exam;

public interface IAttack
{
    public void Attack(ITakeDamage target);
}