﻿using Kata_9;

GameData gameData = new GameData();
gameData.GameLoop();



