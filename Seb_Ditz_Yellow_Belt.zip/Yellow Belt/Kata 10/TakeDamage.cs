namespace Kata_10;

public abstract class ITakeDamage
{
    public abstract void TakeDamage();
}