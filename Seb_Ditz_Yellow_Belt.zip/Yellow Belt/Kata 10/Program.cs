﻿using Kata_10;

GameData gameData = new GameData();
gameData.GameLoop();



