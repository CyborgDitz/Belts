﻿Attack();
Heal();
void Attack()
{
    int damage = 5;
    Console.WriteLine($"Player dealt {damage}. That's a lot of damage!");
}
void Heal()
{
    int healAmount = 1;
    Console.WriteLine($"Player healed for {healAmount}. That's not a lot...");
}
